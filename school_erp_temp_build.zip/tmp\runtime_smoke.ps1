$ErrorActionPreference = 'Stop'

$repo = Split-Path -Parent $PSScriptRoot
$php = 'C:\xampp\php\php.exe'
$mysql = 'C:\xampp\mysql\bin\mysql.exe'
$mysqld = 'C:\xampp\mysql\bin\mysqld.exe'
$mysqlInstall = 'C:\xampp\mysql\bin\mysql_install_db.exe'
$dbPassword = 'qa123'

$tmpRoot = Join-Path $repo 'tmp\runtime_audit'
$dbRoot = Join-Path $tmpRoot 'mariadb'
$dataDir = Join-Path $dbRoot 'data'
$tmpDbTmp = Join-Path $dbRoot 'tmp'
$sessionDir = Join-Path $tmpRoot 'sessions'
$logDir = Join-Path $tmpRoot 'logs'
$resultDir = Join-Path $tmpRoot 'results'
$iniFile = Join-Path $dbRoot 'my.ini'
$envFile = Join-Path $repo '.env.php'
$dbOut = Join-Path $logDir 'mysqld.stdout.log'
$dbErr = Join-Path $logDir 'mysqld.stderr.log'
$phpOut = Join-Path $logDir 'php-server.stdout.log'
$phpErr = Join-Path $logDir 'php-server.stderr.log'
$sessionBootstrap = Join-Path $repo 'tmp\runtime_session_bootstrap.php'
$dbProc = $null
$phpProc = $null
$originalEnv = Get-Content $envFile -Raw

function Get-FlatSnippet([string]$body, [int]$max = 180) {
    if ($null -eq $body) {
        $body = ''
    }
    $flat = ($body -replace '\s+', ' ').Trim()
    if ($flat.Length -gt $max) {
        return $flat.Substring(0, $max)
    }
    return $flat
}

function Read-ErrorResponse($errRecord) {
    $response = $errRecord.Exception.Response
    if (-not $response) {
        return [pscustomobject]@{ Status = -1; Body = ($errRecord | Out-String) }
    }

    $status = [int]$response.StatusCode
    $stream = $response.GetResponseStream()
    $reader = New-Object System.IO.StreamReader($stream)
    $body = $reader.ReadToEnd()
    $reader.Close()
    return [pscustomobject]@{ Status = $status; Body = $body }
}

function Get-Issue([string]$body, [int]$status) {
    if ($null -eq $body) {
        $body = ''
    }

    $patterns = @(
        'Parse error:.*',
        'Fatal error:.*',
        'Uncaught [^<\r\n]+',
        'SQLSTATE\[[^\]]+\].*',
        'Warning:.*',
        'Deprecated:.*',
        'Database connection failed[^<\r\n]*',
        'Security token missing[^<\r\n]*',
        'Unauthorized\. Please log in\.',
        'Forbidden\. Insufficient permissions\.',
        'Method not allowed'
    )

    foreach ($pattern in $patterns) {
        $match = [regex]::Match($body, $pattern, [System.Text.RegularExpressions.RegexOptions]::Singleline)
        if ($match.Success) {
            return Get-FlatSnippet $match.Value 260
        }
    }

    if ($status -ge 500) {
        return "HTTP $status"
    }

    return ''
}

function Invoke-AuditRequest {
    param(
        [string]$Url,
        [string]$Method = 'GET',
        $Session = $null,
        [hashtable]$Headers = $null,
        $Body = $null,
        [string]$ContentType = $null
    )

    try {
        $params = @{ Uri = $Url; Method = $Method; UseBasicParsing = $true; ErrorAction = 'Stop' }
        if ($Session) {
            $params.WebSession = $Session
        }
        if ($Headers) {
            $params.Headers = $Headers
        }
        if ($null -ne $Body) {
            $params.Body = $Body
        }
        if ($ContentType) {
            $params.ContentType = $ContentType
        }

        $resp = Invoke-WebRequest @params
        $status = [int]$resp.StatusCode
        $body = [string]$resp.Content
    } catch {
        $err = Read-ErrorResponse $_
        $status = [int]$err.Status
        $body = [string]$err.Body
    }

    $issue = Get-Issue $body $status
    $state = if ($issue) { 'error' } elseif ($status -ge 400) { 'http_error' } else { 'ok' }

    [pscustomobject]@{
        Status = $status
        State = $state
        Issue = $issue
        Snippet = (Get-FlatSnippet $body 180)
    }
}

function Invoke-MysqlScript([string]$filePath, [string]$database = '') {
    $args = @('-h', '127.0.0.1', '-P', '3307', '-u', 'root', "-p$dbPassword")
    if ($database) {
        $args += $database
    }

    $content = Get-Content -LiteralPath $filePath -Raw
    $oldEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $output = $content | & $mysql @args 2>&1
        $exitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $oldEap
    }

    [pscustomobject]@{
        ExitCode = $exitCode
        Output = (($output | Out-String).Trim())
    }
}

try {
    if (Test-Path $tmpRoot) {
        Remove-Item -LiteralPath $tmpRoot -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $dataDir, $tmpDbTmp, $sessionDir, $logDir, $resultDir | Out-Null

    & $mysqlInstall -d $dataDir -p $dbPassword -P 3307 -R | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw 'mysql_install_db failed'
    }

    $iniContent = @"
[mysqld]
basedir=C:/xampp/mysql
datadir=$($dataDir -replace '\\', '/')
port=3307
bind-address=127.0.0.1
skip-networking=0
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci
innodb_buffer_pool_size=64M
max_connections=50
tmpdir=$($tmpDbTmp -replace '\\', '/')
pid-file=$($dbRoot -replace '\\', '/')/mysqld.pid
socket=$($dbRoot -replace '\\', '/')/mysql.sock
"@
    Set-Content -LiteralPath $iniFile -Value $iniContent -Encoding ASCII

    $dbProc = Start-Process -FilePath $mysqld -ArgumentList @("--defaults-file=`"$iniFile`"", '--console') -PassThru -WindowStyle Hidden -RedirectStandardOutput $dbOut -RedirectStandardError $dbErr

    $dbReady = $false
    for ($i = 0; $i -lt 40; $i++) {
        try {
            & $mysql -h 127.0.0.1 -P 3307 -u root "-p$dbPassword" -e "SELECT 1" | Out-Null
            if ($LASTEXITCODE -eq 0) {
                $dbReady = $true
                break
            }
        } catch {}
        Start-Sleep -Seconds 1
    }

    if (-not $dbReady) {
        throw 'Temporary MariaDB did not start'
    }

    $setupRun = Invoke-MysqlScript -filePath (Join-Path $repo 'setup.sql')
    if ($setupRun.ExitCode -ne 0) {
        throw ("setup.sql import failed: " + (Get-FlatSnippet $setupRun.Output 300))
    }

    $migrationScripts = @('setup_complete.sql', 'patch_schema.sql', 'add_indexes.sql')
    $migrationResults = foreach ($script in $migrationScripts) {
        $run = Invoke-MysqlScript -filePath (Join-Path $repo $script) -database 'school_erp'
        [pscustomobject]@{
            Script = $script
            ExitCode = $run.ExitCode
            Summary = (Get-FlatSnippet $run.Output 260)
        }
    }

    $expectedTables = @(
        'users', 'classes', 'students', 'attendance', 'fees', 'fee_structures', 'class_subjects', 'salary_structures',
        'exam_results', 'library_books', 'library_issues', 'hostel_rooms', 'hostel_allocations', 'bus_routes',
        'transport_vehicles', 'canteen_items', 'canteen_sales', 'leave_applications', 'payroll', 'notices',
        'complaints', 'homework', 'routine', 'remarks', 'notifications', 'message_threads', 'thread_participants',
        'messages', 'chatbot_logs'
    )

    $tableList = & $mysql -N -B -h 127.0.0.1 -P 3307 -u root "-p$dbPassword" school_erp -e "SELECT table_name FROM information_schema.tables WHERE table_schema='school_erp' ORDER BY table_name;"
    $tableList = @($tableList | Where-Object { $_ -and $_.Trim() -ne '' })
    $missingTables = $expectedTables | Where-Object { $tableList -notcontains $_ }

    $runtimeEnv = $originalEnv
    $runtimeEnv = [regex]::Replace($runtimeEnv, '(?m)^DB_HOST=.*$', 'DB_HOST=127.0.0.1;port=3307')
    $runtimeEnv = [regex]::Replace($runtimeEnv, '(?m)^DB_PASS=.*$', 'DB_PASS=qa123')
    $runtimeEnv = [regex]::Replace($runtimeEnv, '(?m)^APP_URL=.*$', 'APP_URL=http://127.0.0.1:8000')
    Set-Content -LiteralPath $envFile -Value $runtimeEnv -Encoding ASCII

    $phpProc = Start-Process -FilePath $php -ArgumentList @('-d', "session.save_path=`"$sessionDir`"", '-S', '127.0.0.1:8000', '-t', "`"$repo`"") -PassThru -WindowStyle Hidden -RedirectStandardOutput $phpOut -RedirectStandardError $phpErr

    $serverReady = $false
    for ($i = 0; $i -lt 30; $i++) {
        try {
            $probe = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/health.php' -ErrorAction Stop
            if ($probe.StatusCode -eq 200) {
                $serverReady = $true
                break
            }
        } catch {}
        Start-Sleep -Seconds 1
    }

    if (-not $serverReady) {
        throw 'PHP built-in server did not start'
    }

    $baseUrl = 'http://127.0.0.1:8000'
    $authSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession

    $loginPage = Invoke-WebRequest -UseBasicParsing -Uri "$baseUrl/index.php" -WebSession $authSession -ErrorAction Stop
    $loginCsrfMatch = [regex]::Match([string] $loginPage.Content, 'name="csrf_token"\s+value="([^"]+)"')
    if (-not $loginCsrfMatch.Success) {
        throw 'Failed to extract login CSRF token'
    }

    $loginBody = @{
        email = 'admin@school.com'
        password = 'Password@123'
        csrf_token = $loginCsrfMatch.Groups[1].Value
    }

    $null = Invoke-WebRequest -UseBasicParsing -Uri "$baseUrl/index.php" -Method 'POST' -WebSession $authSession -Body $loginBody -ContentType 'application/x-www-form-urlencoded' -MaximumRedirection 5 -ErrorAction Stop

    $dashboardResponse = Invoke-WebRequest -UseBasicParsing -Uri "$baseUrl/dashboard.php" -WebSession $authSession -ErrorAction Stop
    $dashboardBody = [string] $dashboardResponse.Content
    if ($dashboardBody -match 'Sign in' -and $dashboardBody -match 'name="email"') {
        throw 'Audit login did not create an authenticated session'
    }

    $csrfMatch = [regex]::Match($dashboardBody, 'data-csrf="([^"]+)"')
    if (-not $csrfMatch.Success) {
        $csrfMatch = [regex]::Match($dashboardBody, 'name="csrf_token"\s+value="([^"]+)"')
    }
    if (-not $csrfMatch.Success) {
        throw 'Failed to extract authenticated CSRF token'
    }
    $csrfToken = $csrfMatch.Groups[1].Value

    $healthCheck = Invoke-WebRequest -UseBasicParsing -Uri "$baseUrl/api/health.php" -WebSession $authSession -ErrorAction Stop
    if ([string] $healthCheck.Content -notmatch '"tables"') {
        throw 'Authenticated health check did not expose admin-only data'
    }

    $publicPages = @('index.php', 'forgot_password.php', 'reset_password.php', 'privacy-policy.php') | Where-Object { Test-Path (Join-Path $repo $_) }
    $utilityPages = @('check_schema.php', 'patch_db.php', 'diagnostic.php')
    $protectedPages = Get-ChildItem -LiteralPath $repo -Filter *.php |
        Where-Object { $publicPages -notcontains $_.Name -and $utilityPages -notcontains $_.Name } |
        Sort-Object Name |
        Select-Object -ExpandProperty Name

    $pageResults = @()
    foreach ($page in $publicPages) {
        $r = Invoke-AuditRequest -Url "$baseUrl/$page"
        $pageResults += [pscustomobject]@{ Page = $page; Access = 'public'; Method = 'GET'; Status = $r.Status; State = $r.State; Issue = $r.Issue; Snippet = $r.Snippet }
    }
    foreach ($page in $protectedPages) {
        $r = Invoke-AuditRequest -Url "$baseUrl/$page" -Session $authSession
        $pageResults += [pscustomobject]@{ Page = $page; Access = 'auth'; Method = 'GET'; Status = $r.Status; State = $r.State; Issue = $r.Issue; Snippet = $r.Snippet }
    }

    $excludedApiFiles = @(
        'api/bootstrap.php',
        'api/auth/logout.php'
    )

    $apiFiles = Get-ChildItem -LiteralPath (Join-Path $repo 'api') -Recurse -Filter *.php |
        Sort-Object FullName |
        ForEach-Object { $_.FullName.Substring($repo.Length + 1).Replace('\', '/') } |
        Where-Object { $excludedApiFiles -notcontains $_ }

    $apiGetResults = foreach ($rel in $apiFiles) {
        $r = Invoke-AuditRequest -Url "$baseUrl/$rel" -Session $authSession
        [pscustomobject]@{ Endpoint = $rel; Method = 'GET'; Status = $r.Status; State = $r.State; Issue = $r.Issue; Snippet = $r.Snippet }
    }

    $postHeaders = @{ 'X-CSRF-Token' = $csrfToken }
    $postProbes = @(
        @{ Endpoint = 'api/chatbot/chat.php'; Body = '{"message":"hello","language":"en"}'; ContentType = 'application/json' },
        @{ Endpoint = 'api/chatbot/chat.php'; Body = '{"message":"/help","language":"en"}'; ContentType = 'application/json' },
        @{ Endpoint = 'api/auth/create-staff.php'; Body = @{ name = 'Audit Staff'; email = 'audit.staff@example.com'; password = 'Password@123'; role = 'teacher'; csrf_token = $csrfToken }; ContentType = 'application/x-www-form-urlencoded' },
        @{ Endpoint = 'api/students/index.php'; Body = @{ name = 'Audit Student'; admission_no = 'AUD001'; class_id = '1'; csrf_token = $csrfToken }; ContentType = 'application/x-www-form-urlencoded' },
        @{ Endpoint = 'api/classes/index.php'; Body = @{ name = 'Audit Class'; section = 'A'; academic_year = '2025-2026'; csrf_token = $csrfToken }; ContentType = 'application/x-www-form-urlencoded' },
        @{ Endpoint = 'api/attendance/index.php'; Body = @{ student_id = '1'; class_id = '1'; date = '2026-04-17'; status = 'present'; csrf_token = $csrfToken }; ContentType = 'application/x-www-form-urlencoded' },
        @{ Endpoint = 'api/fee/index.php'; Body = @{ student_id = '1'; fee_type = 'Tuition Fee'; total_amount = '1000'; receipt_no = 'AUD-RCP-1'; csrf_token = $csrfToken }; ContentType = 'application/x-www-form-urlencoded' },
        @{ Endpoint = 'api/notifications/index.php'; Body = @{ title = 'Audit Notice'; message = 'Probe'; recipient_id = '1'; csrf_token = $csrfToken }; ContentType = 'application/x-www-form-urlencoded' }
    )

    $apiPostResults = foreach ($probe in $postProbes) {
        $r = Invoke-AuditRequest -Url "$baseUrl/$($probe.Endpoint)" -Method 'POST' -Session $authSession -Headers $postHeaders -Body $probe.Body -ContentType $probe.ContentType
        [pscustomobject]@{ Endpoint = $probe.Endpoint; Method = 'POST'; Status = $r.Status; State = $r.State; Issue = $r.Issue; Snippet = $r.Snippet }
    }

    $result = [pscustomobject]@{
        GeneratedAt = (Get-Date).ToString('s')
        Setup = [pscustomobject]@{
            BaseSetup = [pscustomobject]@{ Script = 'setup.sql'; ExitCode = $setupRun.ExitCode; Summary = (Get-FlatSnippet $setupRun.Output 260) }
            Migrations = $migrationResults
            TableCount = $tableList.Count
            Tables = $tableList
            MissingExpectedTables = $missingTables
        }
        Pages = $pageResults
        ApiGet = $apiGetResults
        ApiPost = $apiPostResults
        PhpServerErrorTail = if (Test-Path $phpErr) { Get-Content -LiteralPath $phpErr -Tail 80 } else { @() }
        DbErrorTail = if (Test-Path $dbErr) { Get-Content -LiteralPath $dbErr -Tail 80 } else { @() }
    }

    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $resultDir 'runtime-results.json') -Encoding UTF8

    $summary = [pscustomobject]@{
        PageErrors = ($pageResults | Where-Object { $_.State -eq 'error' }).Count
        PageTotal = $pageResults.Count
        ApiGetErrors = ($apiGetResults | Where-Object { $_.State -eq 'error' }).Count
        ApiGetTotal = $apiGetResults.Count
        ApiPostErrors = ($apiPostResults | Where-Object { $_.State -eq 'error' }).Count
        ApiPostTotal = $apiPostResults.Count
        MissingExpectedTables = $missingTables.Count
    }

    $summary | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $resultDir 'summary.json') -Encoding UTF8
    $summary | Format-List | Out-String
} catch {
    $failure = ($_ | Out-String).Trim()
    if ($resultDir) {
        $failure | Set-Content -LiteralPath (Join-Path $resultDir 'runtime-error.txt') -Encoding UTF8
    }
    throw
} finally {
    if ($phpProc -and !$phpProc.HasExited) {
        Stop-Process -Id $phpProc.Id -Force
    }
    if ($dbProc -and !$dbProc.HasExited) {
        Stop-Process -Id $dbProc.Id -Force
    }
    Set-Content -LiteralPath $envFile -Value $originalEnv -Encoding ASCII
}
