<?php
/**
 * Data Seeder Script - Generate 10,000+ test records
 * School ERP PHP v3.0 - Load Testing Data Generator
 * 
 * Usage: Run this once to populate database with test data
 * php seed_data.php
 */

require_once __DIR__ . '/../includes/db.php';

echo "🌱 Starting Data Seeder for Load Testing...\n";
echo "===========================================\n\n";

// ============================================
// 1. SEED 200 CLASSES
// ============================================
echo "📚 Seeding 200 Classes...\n";
$classesSeeded = 0;
$sections = ['A', 'B', 'C', 'D'];

for ($i = 1; $i <= 200; $i++) {
    $className = "Class " . (rand(1, 12));
    $section = $sections[array_rand($sections)];
    $capacity = rand(30, 60);
    
    try {
        db_query(
            "INSERT IGNORE INTO classes (name, section, capacity, academic_year) VALUES (?, ?, ?, ?)",
            ["$className $section", $section, $capacity, '2025-2026']
        );
        $classesSeeded++;
    } catch (Exception $e) {
        // Skip duplicates
    }
}
echo "✅ Seeded $classesSeeded classes\n\n";

// Get class IDs for student seeding
$classes = db_fetchAll("SELECT id FROM classes ORDER BY RAND() LIMIT 200");
$classIds = array_column($classes, 'id');

// ============================================
// 2. SEED 5,000 STUDENTS
// ============================================
echo "👨‍🎓 Seeding 5,000 Students...\n";
$genders = ['male', 'female', 'other'];
$firstNames = ['Aarav', 'Vivaan', 'Aditya', 'Vihaan', 'Arjun', 'Sai', 'Reyansh', 'Ayaan', 'Krishna', 'Ishaan', 'Ananya', 'Diya', 'Saanvi', 'Aadhya', 'Pari', 'Myra', 'Riya', 'Aisha', 'Sara', 'Kiara'];
$lastNames = ['Sharma', 'Verma', 'Gupta', 'Malhotra', 'Kapoor', 'Singh', 'Kumar', 'Patel', 'Reddy', 'Nair', 'Joshi', 'Rao', 'Mehta', 'Desai', 'Shah'];

$studentsSeeded = 0;
for ($i = 0; $i < 5000; $i++) {
    $firstName = $firstNames[array_rand($firstNames)];
    $lastName = $lastNames[array_rand($lastNames)];
    $name = "$firstName $lastName";
    $admissionNo = 'ADM' . date('Y') . str_pad($i + 1, 6, '0', STR_PAD_LEFT);
    $classId = $classIds[array_rand($classIds)];
    $rollNumber = 'ROLL' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
    $dob = date('Y-m-d', strtotime('-' . rand(10, 18) . ' years -' . rand(0, 11) . ' months -' . rand(1, 28) . ' days'));
    $gender = $genders[array_rand($genders)];
    $parentName = "Mr/Mrs $lastName";
    $parentPhone = '9' . rand(100000000, 999999999);
    $phone = '9' . rand(100000000, 999999999);
    $email = strtolower($firstName) . '.' . rand(100, 999) . '@test.com';
    $address = rand(1, 999) . ' Test Street, Test City';
    
    try {
        db_query(
            "INSERT IGNORE INTO students (admission_no, roll_number, name, class_id, dob, gender, parent_name, parent_phone, phone, email, address, is_active, admission_date) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())",
            [$admissionNo, $rollNumber, $name, $classId, $dob, $gender, $parentName, $parentPhone, $phone, $email, $address]
        );
        $studentsSeeded++;
    } catch (Exception $e) {
        // Skip duplicates
    }
    
    if ($studentsSeeded % 500 === 0) {
        echo "   Progress: $studentsSeeded / 5,000 students\n";
    }
}
echo "✅ Seeded $studentsSeeded students\n\n";

// ============================================
// 3. SEED 500 STAFF (Users)
// ============================================
echo "👔 Seeding 500 Staff Members...\n";
$roles = ['teacher', 'admin', 'hr', 'accounts', 'librarian', 'canteen', 'conductor', 'driver'];
$departments = ['Science', 'Mathematics', 'English', 'Hindi', 'Social Studies', 'Physical Education', 'Arts', 'Music', 'Administration', 'Accounts'];
$designations = ['Teacher', 'Senior Teacher', 'HOD', 'Coordinator', 'Manager', 'Assistant', 'Clerk', 'Staff'];

$staffSeeded = 0;
for ($i = 0; $i < 500; $i++) {
    $firstName = $firstNames[array_rand($firstNames)];
    $lastName = $lastNames[array_rand($lastNames)];
    $name = "$firstName $lastName";
    $email = strtolower($firstName) . '.staff' . ($i + 1) . '@school.com';
    $password = password_hash('staff123', PASSWORD_BCRYPT);
    $role = $roles[array_rand($roles)];
    $employeeId = 'EMP' . str_pad($i + 1, 5, '0', STR_PAD_LEFT);
    $department = $departments[array_rand($departments)];
    $designation = $designations[array_rand($designations)];
    $phone = '9' . rand(100000000, 999999999);
    
    try {
        db_query(
            "INSERT IGNORE INTO users (employee_id, name, email, password, role, department, designation, phone, is_active, casual_leave_balance, earned_leave_balance, sick_leave_balance) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 12, 15, 10)",
            [$employeeId, $name, $email, $password, $role, $department, $designation, $phone]
        );
        $staffSeeded++;
    } catch (Exception $e) {
        // Skip duplicates
    }
}
echo "✅ Seeded $staffSeeded staff members\n\n";

// Get student and staff IDs for relationship seeding
$students = db_fetchAll("SELECT id, class_id FROM students WHERE is_active = 1 ORDER BY RAND() LIMIT 5000");
$studentIds = array_column($students, 'id');
$staff = db_fetchAll("SELECT id FROM users WHERE role IN ('teacher', 'admin') AND is_active = 1 ORDER BY RAND() LIMIT 200");
$staffIds = array_column($staff, 'id');

// ============================================
// 4. SEED 50,000 ATTENDANCE RECORDS
// ============================================
echo "✅ Seeding 50,000 Attendance Records...\n";
$statuses = ['present', 'present', 'present', 'present', 'absent', 'late', 'excused']; // 57% present

$attendanceSeeded = 0;
for ($i = 0; $i < 50000; $i++) {
    $student = $students[array_rand($students)];
    $date = date('Y-m-d', strtotime('-' . rand(0, 180) . ' days'));
    $status = $statuses[array_rand($statuses)];
    
    try {
        db_query(
            "INSERT IGNORE INTO attendance (student_id, class_id, teacher_id, date, status, sms_sent) 
             VALUES (?, ?, ?, ?, ?, 0)",
            [$student['id'], $student['class_id'], $staffIds[array_rand($staffIds)], $date, $status]
        );
        $attendanceSeeded++;
    } catch (Exception $e) {
        // Skip duplicates (unique constraint on student_id + date)
    }
    
    if ($attendanceSeeded % 10000 === 0) {
        echo "   Progress: $attendanceSeeded / 50,000 attendance records\n";
    }
}
echo "✅ Seeded $attendanceSeeded attendance records\n\n";

// ============================================
// 5. SEED 10,000 FEE RECORDS
// ============================================
echo "💰 Seeding 10,000 Fee Records...\n";
$feeTypes = ['Tuition Fee', 'Transport Fee', 'Library Fee', 'Lab Fee', 'Sports Fee', 'Annual Day Fee'];
$paymentModes = ['cash', 'card', 'upi', 'bank'];

$feesSeeded = 0;
for ($i = 0; $i < 10000; $i++) {
    $student = $students[array_rand($students)];
    $feeType = $feeTypes[array_rand($feeTypes)];
    $totalAmount = rand(5000, 50000);
    $amountPaid = rand(0, $totalAmount);
    $discount = rand(0, 5000);
    $paymentMode = $paymentModes[array_rand($paymentModes)];
    $paidDate = date('Y-m-d', strtotime('-' . rand(0, 365) . ' days'));
    $dueDate = date('Y-m-d', strtotime('-' . rand(0, 30) . ' days'));
    $month = date('F', strtotime($paidDate));
    $year = (int)date('Y', strtotime($paidDate));
    $receiptNo = 'REC' . date('Y') . str_pad($i + 1, 6, '0', STR_PAD_LEFT);
    
    try {
        db_query(
            "INSERT INTO fees (student_id, fee_type, total_amount, amount_paid, discount, payment_method, paid_date, due_date, month, year, receipt_no, collected_by) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [$student['id'], $feeType, $totalAmount, $amountPaid, $discount, $paymentMode, $paidDate, $dueDate, $month, $year, $receiptNo, $staffIds[array_rand($staffIds)]]
        );
        $feesSeeded++;
    } catch (Exception $e) {
        // Continue on error
    }
    
    if ($feesSeeded % 2000 === 0) {
        echo "   Progress: $feesSeeded / 10,000 fee records\n";
    }
}
echo "✅ Seeded $feesSeeded fee records\n\n";

// ============================================
// 6. SEED 5,000 EXAM RESULTS
// ============================================
echo "📝 Seeding 5,000 Exam Results...\n";
$subjects = ['Mathematics', 'Science', 'English', 'Hindi', 'Social Studies', 'Computer Science', 'Physical Education'];
$examNames = ['Unit Test 1', 'Unit Test 2', 'Mid-Term', 'Final Exam', 'Quarterly Test'];

require_once __DIR__ . '/includes/helpers.php';

$examsSeeded = 0;
for ($i = 0; $i < 5000; $i++) {
    $student = $students[array_rand($students)];
    $subject = $subjects[array_rand($subjects)];
    $examName = $examNames[array_rand($examNames)];
    $examDate = date('Y-m-d', strtotime('-' . rand(0, 180) . ' days'));
    $maxMarks = 100;
    $passMarks = 33;
    $marksObtained = rand(10, 100);
    $grade = calculate_grade($marksObtained, $maxMarks);
    $status = ($marksObtained >= $passMarks) ? 'pass' : 'fail';
    
    try {
        // Create exam if not exists
        $exam = db_fetch("SELECT id FROM exams WHERE name = ? AND subject = ? AND class_id = ?", [$examName, $subject, $student['class_id']]);
        if (!$exam) {
            $examId = db_insert(
                "INSERT INTO exams (name, class_id, subject, exam_date, total_marks, passing_marks) VALUES (?, ?, ?, ?, ?, ?)",
                [$examName, $student['class_id'], $subject, $examDate, $maxMarks, $passMarks]
            );
        } else {
            $examId = $exam['id'];
        }
        
        db_query(
            "INSERT IGNORE INTO exam_results (exam_id, student_id, marks_obtained, total_marks, grade, status) VALUES (?, ?, ?, ?, ?, ?)",
            [$examId, $student['id'], $marksObtained, $maxMarks, $grade, $status]
        );
        $examsSeeded++;
    } catch (Exception $e) {
        // Continue on error
    }
    
    if ($examsSeeded % 1000 === 0) {
        echo "   Progress: $examsSeeded / 5,000 exam results\n";
    }
}
echo "✅ Seeded $examsSeeded exam results\n\n";

// ============================================
// 7. SEED 2,000 LIBRARY TRANSACTIONS
// ============================================
echo "📚 Seeding 2,000 Library Transactions...\n";
$bookTitles = ['Physics Vol 1', 'Chemistry Basics', 'Mathematics Guide', 'English Literature', 'History of India', 'Geography Atlas', 'Biology Handbook', 'Computer Science', 'Economics Guide', 'Accounting Basics'];

$booksSeeded = 0;
for ($i = 0; $i < 200; $i++) {
    $title = $bookTitles[array_rand($bookTitles)] . " (Copy " . ($i + 1) . ")";
    $author = $lastNames[array_rand($lastNames)] . ' ' . $firstNames[array_rand($firstNames)];
    $isbn = str_pad(rand(1000000000, 9999999999), 10, '0', STR_PAD_LEFT);
    $totalCopies = rand(1, 5);
    
    try {
        db_query(
            "INSERT IGNORE INTO library_books (isbn, title, author, total_copies, available_copies) VALUES (?, ?, ?, ?, ?)",
            [$isbn, $title, $author, $totalCopies, $totalCopies]
        );
        $booksSeeded++;
    } catch (Exception $e) {
        // Continue
    }
}

$books = db_fetchAll("SELECT id FROM library_books ORDER BY RAND() LIMIT 200");
$bookIds = array_column($books, 'id');

$transactionsSeeded = 0;
foreach ($bookIds as $bookId) {
    for ($j = 0; $j < 10; $j++) {
        $student = $students[array_rand($students)];
        $issueDate = date('Y-m-d', strtotime('-' . rand(1, 60) . ' days'));
        $dueDate = date('Y-m-d', strtotime($issueDate . ' + 7 days'));
        $isReturned = rand(0, 1);
        $returnDate = $isReturned ? date('Y-m-d', strtotime($dueDate . ' -' . rand(0, 5) . ' days')) : null;
        $fineAmount = (!$isReturned && strtotime($dueDate) < time()) ? rand(5, 50) : 0;
        
        try {
            db_query(
                "INSERT INTO library_issues (book_id, student_id, issue_date, due_date, return_date, is_returned, fine_amount, fine_per_day) VALUES (?, ?, ?, ?, ?, ?, ?, 5)",
                [$bookId, $student['id'], $issueDate, $dueDate, $returnDate, $isReturned, $fineAmount]
            );
            $transactionsSeeded++;
        } catch (Exception $e) {
            // Continue
        }
    }
}
echo "✅ Seeded $booksSeeded books and $transactionsSeeded transactions\n\n";

// ============================================
// 8. SEED 3,000 NOTICES
// ============================================
echo "📢 Seeding 3,000 Notices...\n";
$noticeTitles = ['Holiday Notice', 'Exam Schedule', 'PTM Invitation', 'Sports Day', 'Annual Function', 'Fee Due Reminder', 'Library Closure', 'Transport Route Change', 'Uniform Update', 'Parent Meeting'];
$priorities = ['low', 'medium', 'high', 'urgent'];

for ($i = 0; $i < 3000; $i++) {
    $title = $noticeTitles[array_rand($noticeTitles)] . " #" . ($i + 1);
    $content = "This is an automated test notice #$i. Please ignore.";
    $priority = $priorities[array_rand($priorities)];
    $createdBy = $staffIds[array_rand($staffIds)];
    $createdDate = date('Y-m-d H:i:s', strtotime('-' . rand(0, 365) . ' days'));
    
    try {
        db_query(
            "INSERT INTO notices (title, content, audience, priority, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            [$title, $content, json_encode(['all']), $priority, $createdBy, $createdDate]
        );
    } catch (Exception $e) {
        // Continue
    }
}
echo "✅ Seeded 3,000 notices\n\n";

// ============================================
// 9. SEED 10,000 CHATBOT LOGS
// ============================================
echo "🤖 Seeding 10,000 Chatbot Logs...\n";
$intents = ['greeting', 'help', 'student_count', 'fee_pending', 'attendance_today', 'library', 'exams', 'complaints', 'transport', 'hostel', 'canteen', 'homework', 'notices', 'payroll', 'leave', 'knowledge_base', 'unknown'];
$languages = ['en', 'en', 'en', 'hi', 'as'];

for ($i = 0; $i < 10000; $i++) {
    $userId = $studentIds[array_rand($studentIds)];
    $message = "Test message #$i";
    $intent = $intents[array_rand($intents)];
    $language = $languages[array_rand($languages)];
    $responseTime = rand(50, 2000) / 10;
    $createdDate = date('Y-m-d H:i:s', strtotime('-' . rand(0, 180) . ' days'));
    
    try {
        db_query(
            "INSERT INTO chatbot_logs (user_id, user_role, message, language, intent, response, response_time, session_id) VALUES (?, 'student', ?, ?, ?, 'Test response', ?, 'session_$i')",
            [$userId, $message, $language, $intent, $responseTime]
        );
    } catch (Exception $e) {
        // Continue
    }
}
echo "✅ Seeded 10,000 chatbot logs\n\n";

// ============================================
// 10. SEED AUDIT LOGS (5,000)
// ============================================
echo "📋 Seeding 5,000 Audit Logs...\n";
$modules = ['students', 'attendance', 'fees', 'exams', 'library', 'transport', 'hostel', 'canteen', 'homework', 'notices'];
$actions = ['CREATE', 'UPDATE', 'DELETE', 'VIEW', 'EXPORT', 'IMPORT'];

for ($i = 0; $i < 5000; $i++) {
    $userId = $staffIds[array_rand($staffIds)];
    $module = $modules[array_rand($modules)];
    $action = $actions[array_rand($actions)];
    $createdDate = date('Y-m-d H:i:s', strtotime('-' . rand(0, 365) . ' days'));
    
    try {
        db_query(
            "INSERT INTO audit_logs_enhanced (user_id, action, module, record_id, ip_address) VALUES (?, ?, ?, ?, '127.0.0.1')",
            [$userId, $action, $module, rand(1, 9999)]
        );
    } catch (Exception $e) {
        // Continue
    }
}
echo "✅ Seeded 5,000 audit logs\n\n";

// ============================================
// FINAL SUMMARY
// ============================================
echo "===========================================\n";
echo "✅ DATA SEEDING COMPLETE!\n";
echo "===========================================\n\n";

// Count all records
$stats = [
    'Classes' => db_count("SELECT COUNT(*) FROM classes"),
    'Students' => db_count("SELECT COUNT(*) FROM students WHERE is_active = 1"),
    'Staff' => db_count("SELECT COUNT(*) FROM users WHERE is_active = 1 AND role != 'student'"),
    'Attendance' => db_count("SELECT COUNT(*) FROM attendance"),
    'Fees' => db_count("SELECT COUNT(*) FROM fees"),
    'Exams' => db_count("SELECT COUNT(*) FROM exams"),
    'Exam Results' => db_count("SELECT COUNT(*) FROM exam_results"),
    'Library Books' => db_count("SELECT COUNT(*) FROM library_books"),
    'Library Transactions' => db_count("SELECT COUNT(*) FROM library_issues"),
    'Notices' => db_count("SELECT COUNT(*) FROM notices"),
    'Chatbot Logs' => db_count("SELECT COUNT(*) FROM chatbot_logs"),
    'Audit Logs' => db_count("SELECT COUNT(*) FROM audit_logs_enhanced"),
];

echo "📊 Final Statistics:\n";
foreach ($stats as $table => $count) {
    echo sprintf("   %-25s: %d\n", $table, $count);
}

$totalRecords = array_sum($stats);
echo "\n🎯 Total Records: " . number_format($totalRecords) . "\n\n";
echo "✨ Database is now ready for load testing!\n";
