<?php

if ($argc < 4) {
    fwrite(STDERR, "Usage: php runtime_session_bootstrap.php <session_dir> <session_id> <role>\n");
    exit(1);
}

$sessionDir = $argv[1];
$sessionId = $argv[2];
$role = $argv[3];

if (!is_dir($sessionDir) && !mkdir($sessionDir, 0777, true) && !is_dir($sessionDir)) {
    fwrite(STDERR, "Failed to create session directory: {$sessionDir}\n");
    exit(1);
}

session_save_path($sessionDir);
session_id($sessionId);
session_start();

$_SESSION['user_id'] = 1;
$_SESSION['user_name'] = 'Audit Admin';
$_SESSION['user_email'] = 'admin@school.com';
$_SESSION['user_role'] = $role;
$_SESSION['csrf_token'] = 'auditcsrf';
$_SESSION['logged_in_at'] = time();

session_write_close();

echo session_save_path();
