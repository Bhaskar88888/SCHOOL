<?php

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

echo json_encode([
    'session_id' => session_id(),
    'request_cookie' => $_SERVER['HTTP_COOKIE'] ?? '',
    'user_id' => $_SESSION['user_id'] ?? null,
    'user_role' => $_SESSION['user_role'] ?? null,
    'logged_in' => is_logged_in(),
]);
