<?php
if (PHP_SAPI !== 'cli' && PHP_SAPI !== 'phpdbg') {
    http_response_code(403);
    exit('Forbidden');
}
__halt_compiler();
# School ERP PHP v3.0 - Environment Configuration
# =============================================
# XAMPP LOCALHOST VERSION
# Use this file on your local XAMPP server.
# Before final deployment, swap to production values.
# =============================================

# Database Configuration (XAMPP defaults)
DB_HOST=127.0.0.1;port=3307
DB_NAME=school_erp
DB_USER=root
DB_PASS=qa123
DB_CHARSET=utf8mb4

# Application
APP_NAME=School ERP
APP_VERSION=3.0
APP_ENV=production
APP_URL=https://school.kashliv.com
APP_DEBUG=false

# Security (keep same secrets - change only for production)
# IMPORTANT: Each secret must be UNIQUE. Never reuse the same value.
SESSION_SECRET=a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2
CSRF_SECRET=f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8
ENCRYPTION_KEY=1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b

# Session
SESSION_LIFETIME=28800
SESSION_GC_MAXLIFETIME=86400
SESSION_COOKIE_SECURE=true
SESSION_COOKIE_HTTPONLY=true
SESSION_COOKIE_SAMESITE=Lax

# Rate Limiting
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=3600
RATE_LIMIT_AUTH_REQUESTS=10
RATE_LIMIT_AUTH_WINDOW=3600

# Account Lockout
LOCKOUT_ENABLED=true
LOCKOUT_MAX_ATTEMPTS=5
LOCKOUT_DURATION=300

# Password Reset
RESET_TOKEN_EXPIRY=3600

# File Upload
UPLOAD_MAX_SIZE=10485760
UPLOAD_ALLOWED_TYPES=image/jpeg,image/png,image/gif,application/pdf
UPLOAD_PATH=uploads

# Email (PHPMailer SMTP — required for parent credential delivery)
# For Gmail use an App Password: https://myaccount.google.com/apppasswords
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-school-gmail@gmail.com
SMTP_PASS=your-gmail-app-password
SMTP_FROM_EMAIL=noreply@yourschool.com
SMTP_FROM_NAME=School ERP

# SMS Gateway (for parent credential delivery via SMS)
# Options: fast2sms | msg91 | twilio
SMS_ENABLED=false
SMS_GATEWAY=fast2sms
SMS_API_KEY=your-fast2sms-api-key
SMS_SENDER_ID=SCHOOL
TWILIO_SID=
TWILIO_TOKEN=
TWILIO_PHONE=

# AI Chatbot (add your Gemini key for AI features)
GEMINI_API_KEY=
GEMINI_MODEL=gemini-1.5-flash

# PDF Generation
PDF_GENERATOR=html2pdf

# Pagination
PAGINATION_DEFAULT=20
PAGINATION_MAX=100

# Academic Year
CURRENT_ACADEMIC_YEAR=2025-2026

# Timezone
APP_TIMEZONE=Asia/Kolkata

# ── JWT (Mobile App Authentication) ─────────────────────────────────────
# Generate strong secret: openssl rand -hex 32
# CHANGE THIS before production deployment!
JWT_SECRET=REPLACE_WITH_STRONG_64_CHAR_SECRET_BEFORE_PRODUCTION

# ── FCM (Firebase Cloud Messaging — Push Notifications) ─────────────────
# Get server key from Firebase Console → Project Settings → Cloud Messaging
FCM_ENABLED=false
FCM_SERVER_KEY=your-fcm-server-key-from-firebase-console













