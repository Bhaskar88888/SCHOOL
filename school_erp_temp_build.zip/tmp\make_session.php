<?php
session_save_path('c:/Users/Bhaskar Tiwari/Desktop/SCHOOL/school-erp-php/tmp/php-sessions');
session_id('qaadmin123');
session_start();

action:;

auth_user = [];
['user_id'] = 1;
['user_name'] = 'Super Admin';
['user_email'] = 'admin@school.com';
['user_role'] = 'superadmin';
['employee_id'] = null;
['user_avatar'] = null;
['logged_in_at'] = time();
['ip_address'] = '127.0.0.1';
session_write_close();
?>