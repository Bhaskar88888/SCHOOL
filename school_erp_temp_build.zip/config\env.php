<?php
/**
 * Environment Configuration (Legacy Compatibility Layer)
 * School ERP PHP v3.0
 * 
 * This file provides backward compatibility for old code
 * All configuration now loaded from .env.php via env_loader.php
 */

// Load new environment system
require_once __DIR__ . '/../includes/env_loader.php';

// Define legacy constants for backward compatibility
// Only define if not already defined by env_loader
$legacyConstants = [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'school_erp',
    'DB_USER' => 'root',
    'DB_PASS' => '',
    'DB_CHARSET' => 'utf8mb4',
    'JWT_SECRET' => bin2hex(random_bytes(32)),
    'APP_NAME' => 'School ERP',
    'APP_VERSION' => '3.0',
];

foreach ($legacyConstants as $constant => $default) {
    if (!defined($constant)) {
        define($constant, getenv($constant) ?: $default);
    }
}
